# ChordAuth
## ChordAuth is a decentralized authentication system.
## See https://github.com/SeafoodStudios/ChordAuth for more information
